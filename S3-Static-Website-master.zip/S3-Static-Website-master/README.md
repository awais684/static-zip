# S3-Static-Website
it is a static website for aws s3
you can pull it and do practice on it
